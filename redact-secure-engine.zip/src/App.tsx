/**
 * Redact - SECURE ENGINE
 * Premium multi-tool privacy & local file manipulation engine.
 * Exact replication of reference UI with full liquid glassmorphic architecture.
 */

import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  LayoutGrid,
  Heart,
  Settings,
  ArrowLeft,
  ArrowLeftRight,
  Scaling,
  FileText,
  Search,
  X,
  ChevronRight,
  Layers,
  Zap,
  Scissors,
  Lock,
} from 'lucide-react';
import { AppFile, CoreEngineId, NavTabId, SecuritySession } from './types';
import { generateSessionFingerprint } from './utils/crypto';
import { playHaptic } from './utils/audio';

import { PhoneContainer } from './components/PhoneContainer';
import { Header } from './components/Header';
import { HeroCard } from './components/HeroCard';
import { CoreEnginesGrid } from './components/CoreEnginesGrid';
import { MoreEnginesBar } from './components/MoreEnginesBar';
import { BottomNav } from './components/BottomNav';
import { CoreEngineModal } from './components/CoreEngineModal';
import { ImageResizer } from './components/ImageResizer';
import { FormatConverter } from './components/FormatConverter';
import { PdfTools } from './components/PdfTools';
import { SettingsView } from './components/SettingsView';

interface SearchableTool {
  id: string;
  name: string;
  category: string;
  description: string;
  keywords: string[];
  icon: React.ComponentType<{ className?: string }>;
  type: 'subtab' | 'engine';
  subtabId?: 'converter' | 'pdf' | 'resizer';
  engineId?: CoreEngineId;
}

const TOOLS_CATALOG: SearchableTool[] = [
  {
    id: 'resizer',
    name: 'Image Resizer',
    category: 'Imaging & Scale',
    description: 'Custom dimensions, aspect ratio lock, resolution presets (HD, 4K, Avatar)',
    keywords: ['resizer', 'resize', 'scale', 'dimension', 'width', 'height', 'crop', 'ratio'],
    icon: Scaling,
    type: 'subtab',
    subtabId: 'resizer',
  },
  {
    id: 'pdf-tools',
    name: 'PDF ↔ Image Suite',
    category: 'Documents & Pages',
    description: 'Extract PDF pages as crisp images or compile images into a single PDF document',
    keywords: ['pdf', 'pdf to img', 'img to pdf', 'extract', 'pages', 'document', 'pdf to image', 'images to pdf'],
    icon: FileText,
    type: 'subtab',
    subtabId: 'pdf',
  },
  {
    id: 'format-converter',
    name: 'Format Converter',
    category: 'File Conversion',
    description: 'Convert between PNG, JPG/JPEG, WEBP, HEIC/HEIF, GIF, BMP, and SVG',
    keywords: ['converter', 'format', 'convert', 'png', 'jpg', 'jpeg', 'heic', 'webp', 'gif', 'svg'],
    icon: ArrowLeftRight,
    type: 'subtab',
    subtabId: 'converter',
  },
  {
    id: 'merge-engine',
    name: 'Merge Engine',
    category: 'Core Engine',
    description: 'Combine multiple files or images into a single container',
    keywords: ['merge', 'combine', 'join', 'stitch', 'bundle'],
    icon: Layers,
    type: 'engine',
    engineId: 'merge',
  },
  {
    id: 'compress-engine',
    name: 'Compress Engine',
    category: 'Core Engine',
    description: 'Reduce file size and remove metadata while keeping clarity',
    keywords: ['compress', 'optimize', 'shrink', 'reduction', 'savings', 'exif'],
    icon: Zap,
    type: 'engine',
    engineId: 'compress',
  },
  {
    id: 'split-engine',
    name: 'Split Engine',
    category: 'Core Engine',
    description: 'Slice files into secure partitions and chunks',
    keywords: ['split', 'extract', 'partition', 'divide', 'slice'],
    icon: Scissors,
    type: 'engine',
    engineId: 'split',
  },
  {
    id: 'protect-engine',
    name: 'Protect Engine',
    category: 'Core Engine',
    description: 'Zero-knowledge AES-256 client-side file encryption',
    keywords: ['protect', 'secure', 'encrypt', 'aes', 'lock', 'password'],
    icon: Lock,
    type: 'engine',
    engineId: 'protect',
  },
];

export default function App() {
  // Theme Settings
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Navigation State
  const [activeTab, setActiveTab] = useState<NavTabId>('home');
  const [activeToolsSubTab, setActiveToolsSubTab] = useState<'converter' | 'pdf' | 'resizer'>('converter');
  const [toolsSearchQuery, setToolsSearchQuery] = useState<string>('');

  // Filtered tools when searching in Tools tab
  const filteredTools = useMemo(() => {
    const q = toolsSearchQuery.trim().toLowerCase();
    if (!q) return TOOLS_CATALOG;
    return TOOLS_CATALOG.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.keywords.some((k) => k.toLowerCase().includes(q))
    );
  }, [toolsSearchQuery]);

  // Selected File State
  const [selectedFile, setSelectedFile] = useState<AppFile | null>(null);

  // Active Core Engine Modal ('merge' | 'compress' | 'split' | 'protect')
  const [activeCoreEngine, setActiveCoreEngine] = useState<CoreEngineId | null>(null);

  // Session State
  const [session, setSession] = useState<SecuritySession>({
    isActive: true,
    sessionId: `SES-${Math.floor(100000 + Math.random() * 900000)}`,
    startedAt: Date.now(),
    encryptionKeyFingerprint: generateSessionFingerprint(),
    memoryBufferBytes: 0,
    autoWipeMinutes: 15,
    zeroTraceMode: true,
  });

  // Handle dark mode toggle
  const handleToggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  // Handle file selection from HeroCard or elsewhere
  const handleFileSelect = (file: File) => {
    const isImg = file.type.startsWith('image/') || file.name.match(/\.(png|jpe?g|webp|heic|heif|svg|gif|bmp)$/i);
    const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
    const isTxt = file.type.startsWith('text/') || file.name.endsWith('.txt') || file.name.endsWith('.json');

    const newAppFile: AppFile = {
      id: Math.random().toString(36).substring(2, 9),
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      lastModified: file.lastModified,
      dataUrl: isImg ? URL.createObjectURL(file) : undefined,
      isImage: !!isImg,
      isPdf: !!isPdf,
      isText: !!isTxt,
      fileObject: file,
    };

    setSelectedFile(newAppFile);
    setSession((s) => ({
      ...s,
      memoryBufferBytes: s.memoryBufferBytes + file.size,
    }));
  };

  // Clear loaded file
  const handleClearFile = () => {
    if (selectedFile?.dataUrl) {
      URL.revokeObjectURL(selectedFile.dataUrl);
    }
    setSelectedFile(null);
  };

  // Start / Reset Session pill button action
  const handleStartSession = () => {
    playHaptic('success');
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.25 },
      colors: ['#CA4639', '#DF3D30', '#F9E4E3', '#FFFFFF'],
    });
    setSession((prev) => ({
      ...prev,
      isActive: true,
      startedAt: Date.now(),
      sessionId: `SES-${Math.floor(100000 + Math.random() * 900000)}`,
      encryptionKeyFingerprint: generateSessionFingerprint(),
    }));
  };

  return (
    <PhoneContainer darkMode={darkMode}>
      {/* 1. Header (Red paper-plane, Redact, Green active dot, SECURE ENGINE, Moon toggle) */}
      <Header
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        sessionActive={session.isActive}
      />

      {/* Main Tab Screen Content - Scrollable Content Area */}
      <main className="flex-1 w-full overflow-y-auto no-scrollbar">
        {/* Tab 1: HOME (Exact match with reference image) */}
        {activeTab === 'home' && (
          <div
            style={{ paddingBottom: 'var(--content-bottom-padding)' }}
            className="flex flex-col animate-in fade-in duration-300"
          >
            {/* 2. Hero Card: Select File */}
            <HeroCard
              darkMode={darkMode}
              selectedFile={selectedFile}
              onFileSelect={handleFileSelect}
              onClearFile={handleClearFile}
              session={session}
              onStartSession={handleStartSession}
              onOpenResizer={() => {
                setActiveTab('tools');
                setActiveToolsSubTab('resizer');
              }}
              onOpenConverter={() => {
                setActiveTab('tools');
                setActiveToolsSubTab('converter');
              }}
              onOpenPdfTools={() => {
                setActiveTab('tools');
                setActiveToolsSubTab('pdf');
              }}
            />

            {/* 3 & 4. Core Engines (Merge, Compress, Split, Protect) */}
            <CoreEnginesGrid
              darkMode={darkMode}
              onSelectEngine={(engineId) => setActiveCoreEngine(engineId)}
            />

            {/* 5. More Engines Bar (Full Catalog / Format Converter & Tools) */}
            <MoreEnginesBar
              darkMode={darkMode}
              onOpenCatalog={() => {
                setActiveTab('tools');
                setActiveToolsSubTab('converter');
              }}
            />
          </div>
        )}

        {/* Tab 2: TOOLS (Format Converter, PDF ↔ IMG, & Image Resizer) */}
        {activeTab === 'tools' && (
          <div
            style={{ paddingBottom: 'var(--content-bottom-padding)' }}
            className="flex-1 flex flex-col animate-in fade-in duration-200"
          >
            {/* Search Bar at the top of Tools tab */}
            <div className="px-4 pt-1 pb-2">
              <div
                className={`relative flex items-center rounded-2xl border px-3 py-2 transition-all ${
                  darkMode
                    ? 'bg-black/30 border-white/10 text-white focus-within:border-[#CA4639]'
                    : 'bg-white/80 border-black/5 text-[#121212] focus-within:border-[#CA4639] shadow-xs'
                }`}
              >
                <Search className={`w-4 h-4 mr-2.5 shrink-0 ${darkMode ? 'text-white/40' : 'text-gray-400'}`} />
                <input
                  type="text"
                  value={toolsSearchQuery}
                  onChange={(e) => setToolsSearchQuery(e.target.value)}
                  placeholder="Search tools: resizer, pdf, converter, format..."
                  className="w-full bg-transparent text-xs font-medium focus:outline-none placeholder:text-[11px] placeholder:text-gray-400 dark:placeholder:text-white/30"
                />
                {toolsSearchQuery.trim() !== '' && (
                  <button
                    type="button"
                    onClick={() => {
                      playHaptic('tap');
                      setToolsSearchQuery('');
                    }}
                    className="p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-gray-400 hover:text-black dark:hover:text-white transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* If searching, show live filtered catalog tools */}
            {toolsSearchQuery.trim() !== '' ? (
              <div className="px-4 py-2 flex flex-col gap-2.5">
                <div className="flex items-center justify-between px-1">
                  <span className="text-[10px] font-bold text-[#8A8A8A] tracking-[0.16em] uppercase">
                    SEARCH RESULTS ({filteredTools.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      playHaptic('tap');
                      setToolsSearchQuery('');
                    }}
                    className="text-[10px] font-bold text-[#CA4639] hover:underline uppercase"
                  >
                    Clear Filter
                  </button>
                </div>

                {filteredTools.length > 0 ? (
                  <div className="flex flex-col gap-2">
                    {filteredTools.map((tool) => {
                      const IconComp = tool.icon;
                      return (
                        <div
                          key={tool.id}
                          onClick={() => {
                            playHaptic('pop');
                            if (tool.type === 'subtab' && tool.subtabId) {
                              setActiveToolsSubTab(tool.subtabId);
                              setToolsSearchQuery('');
                            } else if (tool.type === 'engine' && tool.engineId) {
                              setActiveCoreEngine(tool.engineId);
                            }
                          }}
                          className={`p-3.5 rounded-2xl flex items-center justify-between cursor-pointer transition-all duration-200 active:scale-[0.98] border ${
                            darkMode
                              ? 'bg-black/30 hover:bg-black/45 border-white/10'
                              : 'bg-white/70 hover:bg-white border-black/5 shadow-xs'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                                darkMode ? 'bg-[#3D2527] text-[#DF3D30]' : 'bg-[#F9E4E3] text-[#DF3D30]'
                              }`}
                            >
                              <IconComp className="w-5 h-5 stroke-[2.2]" />
                            </div>
                            <div className="flex flex-col text-left">
                              <span
                                className={`text-xs font-bold leading-tight ${
                                  darkMode ? 'text-white' : 'text-[#121212]'
                                }`}
                              >
                                {tool.name}
                              </span>
                              <span className="text-[10px] text-[#8A8A8A] line-clamp-1 mt-0.5">
                                {tool.description}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 shrink-0 ml-2">
                            <span className="text-[10px] font-bold text-[#CA4639] bg-[#CA4639]/10 dark:bg-[#CA4639]/20 px-2 py-0.5 rounded-full">
                              Open
                            </span>
                            <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div
                    className={`p-6 rounded-2xl text-center flex flex-col items-center justify-center border ${
                      darkMode ? 'bg-black/20 border-white/5' : 'bg-white/50 border-black/5'
                    }`}
                  >
                    <Search className="w-8 h-8 text-[#8A8A8A] mb-2 opacity-50" />
                    <p className={`text-xs font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                      No tools found matching &ldquo;{toolsSearchQuery}&rdquo;
                    </p>
                    <p className="text-[11px] text-[#8A8A8A] mt-1 max-w-xs">
                      Try searching for &quot;resizer&quot;, &quot;converter&quot;, &quot;pdf&quot;, &quot;png&quot;, &quot;heic&quot;, or &quot;compress&quot;.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        playHaptic('tap');
                        setToolsSearchQuery('');
                      }}
                      className="mt-3 px-3 py-1.5 rounded-full bg-[#CA4639] text-white text-[11px] font-bold shadow-xs active:scale-95 transition-all"
                    >
                      Clear Search
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                {/* Liquid Glass Sub-Tool Switcher */}
                <div className="px-4 pt-1 pb-2">
                  <div
                    className={`p-1 rounded-2xl flex items-center border transition-all ${
                      darkMode ? 'bg-black/30 border-white/10' : 'bg-white/60 border-black/5 shadow-xs'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        playHaptic('tap');
                        setActiveToolsSubTab('converter');
                      }}
                      className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${
                        activeToolsSubTab === 'converter'
                          ? 'bg-[#CA4639] text-white shadow-sm'
                          : darkMode
                          ? 'text-white/70 hover:text-white'
                          : 'text-gray-600 hover:text-black'
                      }`}
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                      <span>Converter</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        playHaptic('tap');
                        setActiveToolsSubTab('pdf');
                      }}
                      className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${
                        activeToolsSubTab === 'pdf'
                          ? 'bg-[#CA4639] text-white shadow-sm'
                          : darkMode
                          ? 'text-white/70 hover:text-white'
                          : 'text-gray-600 hover:text-black'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>PDF ↔ IMG</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        playHaptic('tap');
                        setActiveToolsSubTab('resizer');
                      }}
                      className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${
                        activeToolsSubTab === 'resizer'
                          ? 'bg-[#CA4639] text-white shadow-sm'
                          : darkMode
                          ? 'text-white/70 hover:text-white'
                          : 'text-gray-600 hover:text-black'
                      }`}
                    >
                      <Scaling className="w-3.5 h-3.5" />
                      <span>Resizer</span>
                    </button>
                  </div>
                </div>

                {/* Sub-tool body */}
                {activeToolsSubTab === 'converter' && (
                  <FormatConverter
                    darkMode={darkMode}
                    initialFile={selectedFile}
                    onFileChange={handleFileSelect}
                  />
                )}

                {activeToolsSubTab === 'pdf' && (
                  <PdfTools
                    darkMode={darkMode}
                    initialFile={selectedFile}
                    onFileChange={handleFileSelect}
                  />
                )}

                {activeToolsSubTab === 'resizer' && (
                  <ImageResizer
                    darkMode={darkMode}
                    initialFile={selectedFile}
                    onFileChange={handleFileSelect}
                  />
                )}
              </>
            )}
          </div>
        )}

        {/* Tab 3: FAVOURITE (Minimal Placeholder without extra features) */}
        {activeTab === 'favourite' && (
          <div
            style={{ paddingBottom: 'var(--content-bottom-padding)' }}
            className="flex-1 flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-200"
          >
            <div
              className={`w-full max-w-sm rounded-[28px] p-8 flex flex-col items-center ${
                darkMode ? 'liquid-glass-dark' : 'liquid-glass'
              }`}
            >
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 ${
                  darkMode ? 'bg-[#3D2527]' : 'bg-[#F9E4E3]'
                }`}
              >
                <Heart className="w-7 h-7 text-[#DF3D30]" />
              </div>
              <h2
                className={`text-xl font-bold ${
                  darkMode ? 'text-white' : 'text-[#121212]'
                }`}
              >
                Favourite
              </h2>
              <p className="text-[10px] font-bold text-[#8A8A8A] tracking-[0.16em] uppercase mt-0.5 mb-3">
                SAVED ENGINES
              </p>
              <p
                className={`text-xs leading-relaxed max-w-xs mb-6 ${
                  darkMode ? 'text-white/70' : 'text-gray-600'
                }`}
              >
                No saved engines. Use the Core Engines on Home.
              </p>
              <button
                type="button"
                onClick={() => {
                  playHaptic('tap');
                  setActiveTab('home');
                }}
                className="px-5 py-2.5 rounded-full bg-[#CA4639] hover:bg-[#B53C30] text-white text-xs font-bold tracking-wider uppercase transition-all shadow-sm active:scale-95 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Home</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: SETTINGS (Replicated from user reference screenshot without colour/theme) */}
        {activeTab === 'settings' && (
          <SettingsView
            darkMode={darkMode}
            onBack={() => setActiveTab('home')}
          />
        )}
      </main>

      {/* 6. Bottom Navigation Floating Liquid Glass Pill */}
      <BottomNav
        darkMode={darkMode}
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
      />

      {/* Interactive Core Engine Modals (Merge, Compress, Split, Protect) */}
      {activeCoreEngine && (
        <CoreEngineModal
          engineId={activeCoreEngine}
          darkMode={darkMode}
          initialFile={selectedFile}
          onClose={() => setActiveCoreEngine(null)}
          onReplaceFile={(f) => handleFileSelect(f)}
        />
      )}
    </PhoneContainer>
  );
}
